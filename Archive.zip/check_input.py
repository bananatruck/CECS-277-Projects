def get_int_range(min_val, max_val):
    """
    Prompts the user for an integer input within a specified range.

    Parameters:
    min_val (int): The minimum acceptable value.
    max_val (int): The maximum acceptable value.

    Returns:
    int: The user's input as an integer within the specified range.
    """
    while True:
        try:
            value = int(input("Please enter a number: "))
            if min_val <= value <= max_val:
                return value
            else:
                print(f"Please enter a number between {min_val} and {max_val}.")
        except ValueError:
            print("Invalid input. Please enter an integer.")
