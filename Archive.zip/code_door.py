from door import Door
import random

class CodeDoor(Door):
    def __init__(self):
        self.code = [random.choice(['X', 'O']) for _ in range(3)]
        self.attempts = ['_', '_', '_']
        self.is_open = False

    def examine_door(self):
        return "A door with a coded keypad with three characters. Each key toggles a value between 'X' and 'O'."

    def menu_options(self):
        return "1. Press Key 1\n2. Press Key 2\n3. Press Key 3"

    def get_menu_max(self):
        return 3

    def attempt(self, option):
        self.toggle(option - 1)
        if self.attempts == self.code:
            self.is_open = True
            return f"Code entered: {''.join(self.attempts)}. The door opens."
        else:
            return f"Code entered: {''.join(self.attempts)}. Some keys are incorrect."

    def is_unlocked(self):
        return self.is_open

    def clue(self):
        correct_positions = sum(1 for at, co in zip(self.attempts, self.code) if at == co)
        return f"{correct_positions} out of 3 characters are correct."

    def success(self):
        return "Congratulations, the code is correct, and the door opens."

    def toggle(self, index):
        self.attempts[index] = 'X' if self.attempts[index] == 'O' else 'O'
