from door import Door
import random

class ComboDoor(Door):
    def __init__(self):
        self.combination = random.randint(1, 10)
        self.is_open = False

    def examine_door(self):
        return "A door with a combination lock. You can spin the dial to a number 1-10."

    def menu_options(self):
        return "Enter a number (1-10): "

    def get_menu_max(self):
        return 10

    def attempt(self, option):
        if option == self.combination:
            self.is_open = True
            return f"You turn the dial to... {option}. You found the correct value and opened the door."
        elif option < self.combination:
            return "Try a higher number."
        else:
            return "Try a lower number."

    def is_unlocked(self):
        return self.is_open

    def clue(self):
        return "The combination is a number between 1 and 10."

    def success(self):
        return "Congratulations, you've unlocked the combo door."
