from door import Door
import random

class DeadboltDoor(Door):
    def __init__(self):
        self.bolts = [random.choice([True, False]) for _ in range(2)]

    def examine_door(self):
        return "A door with two deadbolts. Both need to be unlocked to open the door but you can't tell if each one is locked or unlocked."

    def menu_options(self):
        return "1. Toggle bolt 1\n2. Toggle bolt 2"

    def get_menu_max(self):
        return 2

    def attempt(self, option):
        self.bolts[option - 1] = not self.bolts[option - 1]
        if all(not bolt for bolt in self.bolts):
            return "You toggle the bolt. The door seems to be unlocked now."
        return "You toggle the bolt. The door still seems to be locked."

    def is_unlocked(self):
        return all(not bolt for bolt in self.bolts)

    def clue(self):
        if any(not bolt for bolt in self.bolts):
            return "You jiggle the door...it seems like one of the bolts is unlocked."
        return "The door seems completely locked. Try toggling the bolts."

    def success(self):
        return "Congratulations, both deadbolts are unlocked, and the door opens."
