from door import Door
import random

class LockedDoor(Door):
    def __init__(self):
        self.key_location = random.choice(['mat', 'flower pot', 'fake rock'])
        self.is_open = False

    def examine_door(self):
        return "A locked door. The key is hidden nearby."

    def menu_options(self):
        return "1. Look under the mat.\n2. Look under the flower pot.\n3. Look under the fake rock."

    def get_menu_max(self):
        return 3

    def attempt(self, option):
        locations = ['mat', 'flower pot', 'fake rock']
        chosen_location = locations[option - 1]
        if chosen_location == self.key_location:
            self.is_open = True
            return "You found the key and unlocked the door."
        else:
            return "You didn't find the key. Look somewhere else."

    def is_unlocked(self):
        return self.is_open

    def clue(self):
        return "The key is hidden nearby. Keep looking."

    def success(self):
        return "Congratulations, you've unlocked the door."
