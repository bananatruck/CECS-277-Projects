import random
from basic_door import BasicDoor
from locked_door import LockedDoor
from deadbolt_door import DeadboltDoor
from combo_door import ComboDoor
from code_door import CodeDoor
# Assuming check_input.py contains a get_int_range function
from check_input import get_int_range

def open_door(door):
    print(door.examine_door())
    while not door.is_unlocked():
        print(door.menu_options())
        # Adjusting for ComboDoor's unique input style
        if isinstance(door, ComboDoor):
            choice = get_int_range(1, door.get_menu_max())
        else:
            choice = get_int_range(1, door.get_menu_max())
        print(door.attempt(choice))
        if not door.is_unlocked():
            print(door.clue())
    print(door.success())

def main():
    doors = [BasicDoor, LockedDoor, DeadboltDoor, ComboDoor, CodeDoor]  # Ensure all door classes are included
    print("Welcome to the Escape Room.")
    for _ in range(3):
        door_class = random.choice(doors)
        door_instance = door_class()
        open_door(door_instance)
    print("Congratulations! You escaped...this time.")

if __name__ == "__main__":
    main()
