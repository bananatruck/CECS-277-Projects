#CECS 277 
#LAB-10
#TIRTH JAYESH THAKKAR
#MOHIT RAJUBHAI MORI
#In this code we followed the guidelines and instructions given by the TA and Professor.
#Tirth and Mohit, we both had given our efforts and worked on the base, concepts and designing this  lab
#We have used various concepts taught in classes like defining a function, enumerate, reading a file, caliing from other files, random, import  and so on.
#We did our test runs, and made sure the program is fail proof and handles bad input well
#We also showed the code to our TA, who gave us comments for it and helped us with an issue we faced, and hence we got the lab done perfectly.

import random
from hero import Hero
from beg_factory import BeginnerFactory
from exp_factory import ExpertFactory


def main():
    print("Monster Trials")
    hero_name = input("What is your name? ")
    hero = Hero(hero_name)
    factories = [BeginnerFactory(), BeginnerFactory(), ExpertFactory()]
    monsters = [factory.create_random_enemy() for factory in factories]

    while monsters and hero.hp > 0:
        print(f"\nYou will face a series of {len(monsters)} monsters, {hero.name}.")
        for idx, monster in enumerate(monsters):
            print(f"{idx + 1}. {monster.name} HP: {monster.hp}")
        
        choice = int(input("Enter Choice: ")) - 1
        monster = monsters[choice]
        
        attack_type = int(input(f"{hero.name} HP: {hero.hp}\n1. Sword Attack\n2. Arrow Attack\nEnter choice: "))
        if attack_type == 1:
            print(hero.melee_attack(monster))
        else:
            print(hero.ranged_attack(monster))
        
        if monster.hp > 0:
            print(monster.melee_attack(hero))
        else:
            print(f"You have slain the {monster.name}")
            monsters.remove(monster)
        
        if not monsters:
            print("Congratulations! You defeated all three monsters! Game Over")
        elif hero.hp <= 0:
            print("You have been defeated. Game Over")
            
if __name__ == "__main__":
    main()
