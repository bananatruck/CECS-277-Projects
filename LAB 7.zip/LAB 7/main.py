from atbash import AtbashCipher
from caesar_cipher import CaesarCipher

def main():
    choice = input("Secret Decoder Ring:\n1. Encrypt\n2. Decrypt\n")
    if choice == "1":
        encrypt()
    elif choice == "2":
        decrypt()
    else:
        print("Invalid choice.")

def encrypt():
    cipher_type = input("Enter encryption type:\n1. Atbash\n2. Caesar\n")
    message = input("Enter message: ")
    if cipher_type == "1":
        cipher = AtbashCipher()
    elif cipher_type == "2":
        shift = int(input("Enter shift value: "))
        cipher = CaesarCipher(shift)
    else:
        print("Invalid encryption type.")
        return
    encrypted_message = cipher.encrypt_message(message)
    with open("message.txt", "w") as file:
        file.write(encrypted_message)
    print('Encrypted message saved to "message.txt".')

def decrypt():
    cipher_type = input("Enter decryption type:\n1. Atbash\n2. Caesar\n")
    if cipher_type == "1":
        cipher = AtbashCipher()
    elif cipher_type == "2":
        shift = int(input("Enter shift value: "))
        cipher = CaesarCipher(shift)
    else:
        print("Invalid decryption type.")
        return
    with open("message.txt", "r") as file:
        encrypted_message = file.read()
    decrypted_message = cipher.decrypt_message(encrypted_message)
    print(f"Decrypted message: {decrypted_message}")

if __name__ == "__main__":
    main()
