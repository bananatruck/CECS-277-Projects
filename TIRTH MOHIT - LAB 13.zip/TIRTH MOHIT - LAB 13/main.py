#CECS 277 
#LAB-13
#TIRTH THAKKAR
#MOHIT MORI
#In this code we followed the guidelines and instructions given by the TA and Professor.
#It is a pupoy stimulator program.
#TIRTH and MOHIT, we both had given our efforts and worked on the base, concepts and designing this  lab
#We have used various concepts taught in classes like defining a function, enumerate, reading a file, caliing from other files, random, import  and so on.
#We did our test runs, and made sure the program is fail proof and handles bad input well
#We also showed the code to our TA, who gave us comments for it and helped us with an issue we faced, and hence we got the lab done perfectly.


import puppy
import check_input
  
def main():
  """Main functions that displays a menu that allows the user to play with or feed the puppy."""
  
  p = puppy.Puppy()

  print("Congratulations on your new puppy!")
 
  while True: 
    print("What would you like to do? ")
    print("1. Feed the puppy\n2. Play with the puppy\n3. Quit")
    choice = check_input.get_int_range("Enter choice: ", 1, 3)
    print()
  
    if choice == 1: 
      print(p.give_food())
  
    elif choice == 2: 
      print(p.throw_ball())
  
    elif choice == 3: 
      p.reset()
      break
    
main()